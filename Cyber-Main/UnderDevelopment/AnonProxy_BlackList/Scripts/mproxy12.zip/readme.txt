MultiProxy is a multifunctional personal proxy server you can install to 
help speed up your downloads, especially if you are trying to get several 
files form overseas or from otherwise rather slow server. It can also help 
protect your privacy by dynamically connecting to non-transparent anonimizing 
public proxy servers only. You can also test a list of proxy servers and 
sort them by connection speed and level of anonimity.

MultiProxy is a Freeware program. You can distribute it freely, but you can 
use it only for personal, educational or non-profit purposes. You can't make
profit by using or charge for MultiProxy or its use.


INSTALLATION
------------
Run the self-extracting file MPROXY12.EXE to install MultiProxy. 
The installation wizard will guide you through the install process.
Please check our web site occasionally for updates. Several enhanced
features are planned for future releases.

WARRANTY DISCLAIMER
-------------------
THE SOFTWARE IS PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND. TO THE MAXIMUM
EXTENT PERMITTED BY APPLICABLE LAW, MISHKINSOFT AND/OR AUTHOR OF THIS SOFTWARE,
FURTHER DISCLAIMS ALL WARRANTIES, INCLUDING WITHOUT LIMITATION ANY
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
AND NONINFRINGEMENT. THE ENTIRE RISK ARISING OUT OF THE USE OR PERFORMANCE
OF THE PRODUCT AND DOCUMENTATION REMAINS WITH RECIPIENT. TO THE MAXIMUM EXTENT
PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL MISHKINSOFT AND/OR AUTHOR OF 
THIS PROGRAM BE LIABLE FOR ANY CONSEQUENTIAL, INCIDENTAL, DIRECT, INDIRECT, 
SPECIAL, PUNITIVE, OR OTHER DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION,
DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS 
INFORMATION, OR OTHER PECUNIARY LOSS) ARISING OUT OF THIS AGREEMENT OR THE 
USE OF OR INABILITY TO USE THE PRODUCT, EVEN IF MISHKINSOFT HAS BEEN ADVISED 
OF THE POSSIBILITY OF SUCH DAMAGES.

HOW TO CONTACT
--------------
http://proxy.nikto.net
ww@pobox.com
