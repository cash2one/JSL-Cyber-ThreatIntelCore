package main

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

// TODO: Tests.

func TestFacebookPublicMessagesByKeyword(t *testing.T) {
	assert.Equal(t, "foo", "foo", "should be foo")

}
